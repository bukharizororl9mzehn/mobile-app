﻿using Android.App;
using Android.OS;
using Android.Support.V7.App;
using Android.Runtime;
using Android.Widget;
using Xamarin.Essentials;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System;


namespace XamarinsingleApp1
{
	public class RequestBody
	{
		public string device;
		[JsonProperty("internet-connected")]
		public string internetconnected;
		public string charging;
		public string battery;
		public string location;
	}
	[Activity(Label = "Bukhari Mobile Info App", Theme = "@style/AppTheme", MainLauncher = true)]
	public class MainActivity : AppCompatActivity
	{
		
		protected override void OnCreate(Bundle savedInstanceState)
		{
		
			TextView tv = null;
			string locationdetails = null;
			string internetaccessstatus = "false";
			string deviceId="";
			string batterystate="";

			try
			{
				base.OnCreate(savedInstanceState);
				Xamarin.Essentials.Platform.Init(this, savedInstanceState);
				// Set our view from the "main" layout resource
				SetContentView(Resource.Layout.activity_main);
				Task<PermissionStatus> task1 = Task.Run<PermissionStatus>(async () => await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>());
				PermissionStatus ps = task1.Result;
				if (ps != PermissionStatus.Granted)
				{
					task1 = MainThread.InvokeOnMainThreadAsync<PermissionStatus>(async () => await Permissions.RequestAsync<Permissions.LocationWhenInUse>());
					ps = task1.Result;
				}

				Button btClose = FindViewById<Button>(Resource.Id.btclose);
				btClose.Click += BtClose_Click;



				try
				{
					Android.Telephony.TelephonyManager tm = (Android.Telephony.TelephonyManager)this.GetSystemService(Android.Content.Context.TelephonyService);
					tv = FindViewById<TextView>(Resource.Id.tvimeivalue);
					deviceId = tm.GetImei(1);
					tv.Text = deviceId;
				}

				catch (Exception ex)
				{
					tv.Text = ex.Message;
				}
				//Internet connectivity
				TextView tvinternetconvalue = FindViewById<TextView>(Resource.Id.tvinternetconvalue);

				try
				{
					var current = Connectivity.NetworkAccess;
					
					if (current == NetworkAccess.Internet)
					{
						internetaccessstatus = "true";
					}
					tvinternetconvalue.Text = internetaccessstatus;
				}
				catch (Exception ex)
				{
					tvinternetconvalue.Text = ex.Message;
				}

								

				//Find battery details
				var level = Battery.ChargeLevel;
				int levelinpercentag =(int) (level * 100);
				TextView tvchargingvalue = FindViewById<TextView>(Resource.Id.tvchargevalue);
				tvchargingvalue.Text = levelinpercentag.ToString() ;

				
				TextView tvbatterystatevalue = FindViewById<TextView>(Resource.Id.tvbatterystatevalue);
				try
				{
					 batterystate = GetBatteryState();
					tvbatterystatevalue.Text = batterystate;
				}
				catch (Exception ex)
				{
					tvbatterystatevalue.Text = ex.Message;
				}

				//Location Infromation
				TextView tvlocationvalue = FindViewById<TextView>(Resource.Id.tvlocationvalue);
				try
				{
					Android.Locations.LocationManager locationManager = (Android.Locations.LocationManager)this.GetSystemService(LocationService);
					Android.Locations.Location location = locationManager.GetLastKnownLocation(Android.Locations.LocationManager.GpsProvider);
					double latitude = location.Latitude;
					double Longitude = location.Longitude;
					locationdetails = latitude.ToString() + ", " + Longitude.ToString();
					tvlocationvalue.Text = locationdetails;
				}
				catch (Exception ex)
				{
					tvlocationvalue.Text = ex.Message;
				}


				//update data in cloud
				var requestBody = new RequestBody();
				requestBody.device = deviceId;
				requestBody.internetconnected = internetaccessstatus;
				requestBody.battery = level.ToString();
				requestBody.location = locationdetails;
				requestBody.charging = batterystate;
				UpdateDatainCloud(requestBody);
			}
			catch (Exception ex)
			{

				Console.WriteLine(ex.Message);
			}
			


		}

	
		public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
		{
			Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

			base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
		}

		private void BtClose_Click(object sender, EventArgs eventArgs)
		{
			System.Diagnostics.Process.GetCurrentProcess().CloseMainWindow();

		}
		private string GetBatteryState()
		{
			var state = Battery.State;
			string batterystate = "";
			switch (state)
			{
				case BatteryState.Charging:
					batterystate = "charging";
					break;
				case BatteryState.Full:
					// Battery is full
					batterystate = "full";
					break;
				case BatteryState.Discharging:
				case BatteryState.NotCharging:
					// Currently discharging battery or not being charged
					batterystate = "NotCharging";
					break;
				case BatteryState.NotPresent:
					// Battery doesn't exist in device (desktop computer)
					batterystate = "NotPresent";
					break;
				case BatteryState.Unknown:
					// Unable to detect battery state
					batterystate = "Unknown";
					break;
			}
			return batterystate;
		}

		private void UpdateDatainCloud(RequestBody requestBody1)
		{
			//var requestBody = new RequestBody()
			//{
			//	device = "540596791245867",
			//	internetconnected = "true",
			//	charging = "true",
			//	battery = "98",
			//	location = "27.994572,752613285"
			//};

			TextView tvError = FindViewById<TextView>(Resource.Id.tvError);
			try
			{

				var json = JsonConvert.SerializeObject(requestBody1);
				var data = new StringContent(json, Encoding.UTF8, "application/json");
				var url = "http://143.244.138.96:2110/api/status";
				using var client = new HttpClient();
				var response = client.PostAsync(url, data);
				var result = response.Result.StatusCode;
				if (result == System.Net.HttpStatusCode.OK)
				{
					tvError.Text = "data Updated on " + DateTime.Now.ToString();
				}
			}
			catch (Exception ex)
			{
				tvError.Text = ex.Message;
			}
		}
	}
}